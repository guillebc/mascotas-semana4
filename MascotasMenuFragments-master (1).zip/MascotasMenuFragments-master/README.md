# MascotasMenuFragments
Aplicación de mascotas. Menús y Fragments.


# Trabajo realizado para la semana 4 del curso.


 * Pantalla principal que contiene el ViewPager que maneja los Fragments
![alt text](img/MascotasMenuFragments1.png "Pantalla Principal")


 * Pantalla  muestra el PerfilFragment de la mascota
![alt text](img/MascotasMenuFragments2.png "Pantalla Perfil")


 * Pantalla  muestra las mascotas favoritas
![alt text](img/MascotasMenuFragments3.png "Pantalla Favoritos")

 * Menú de opciones: Contacto y Acerca de
 Se agregan los menús solicitados
![alt text](img/MascotasMenuFragments4.png "Menú de Opciones")

* Pantalla de contacto
 se capturan los datos solicitados
![alt text](img/MascotasMenuFragments5.png "Pantalla Contacto")

 * Se muestra un ProgressDialog que muestra un mensaje Enviando correo.
 progreso de envío del mensaje
![alt text](img/MascotasMenuFragments6.png "Progreso del envío del correo")

* Se muestra un Toast confirmando que el mensaje se ha enviado.
 Mensaje Enviado.
![alt text](img/MascotasMenuFragments7.png "Mensaje de confirmación")

 * Mensaje recibido en un dispositivo físico.
 Confirmación del correo electrónico recibido
![alt text](img/MascotasMenuFragments8.png "Mensaje Recibido")